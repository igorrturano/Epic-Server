Olivenbaum 0x411e
Bl�tter: 0x411f und 0x4120 (Fruchtversion)

Aprikosenbaum: 0x40fa 
Bl�tter: 0x40fb und 0x40fc (Fruchtversion)

BITTE UBERPATCHEN!